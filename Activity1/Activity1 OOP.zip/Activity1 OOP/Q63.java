import java.util.Arrays;

public class Q63 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 int[] arr1 = {3,4,9,8,2,11};
	      int[] arr2 = {6,7,5,4,9,8};
	      boolean isEqual = Arrays.equals(arr1, arr2);
	      if (isEqual) {
	         System.out.println("The two arrays are equal.");
	      } else {
	         System.out.println("The two arrays are not equal.");
	      }

	}

}
